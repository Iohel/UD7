export default{
    name: "Footerpost",
    template:`
        <footer class="container text-center">
            <div class="row  d-none d-md-flex bg-primary">
                <a href="" class="col border text-dark">Twitter</a>
                <a href="" class="col border text-dark">Faceboox</a>
                <a hr ef="" class="col border text-dark">Instagram</a>
                <a href="" class="col border text-dark">Telegram</a>
                <a href="" class="col border text-dark">Discord</a>
            </div>
        </footer>
    `,
}
