export default{
    name:"Headerpost",
    template:`
        <header>
            <div>
                <button>Home</button>
                <button>Theme</button>
                <button>Sort</button>
                <button>Contact</button>
                <button>Administrator</button>
                <button>Settings</button>
                <button>Username</button>
                <button>Logout</button>
            </div>
        </header> 
    `
    
}